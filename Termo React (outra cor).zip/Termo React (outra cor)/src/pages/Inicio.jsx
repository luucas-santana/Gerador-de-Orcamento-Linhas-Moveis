import Sidebar from "../components/Sidebar"
import Cancelamento from "./Cancelamento"
import { ArrowFatLeftIcon } from "@phosphor-icons/react";

function Inicio() {
    return (
        <div className='bg-white flex items-center flex-col'>
            <p className="font-semibold text-slate-600 text-xl">Início</p>
        </div>
    )
}

export default Inicio