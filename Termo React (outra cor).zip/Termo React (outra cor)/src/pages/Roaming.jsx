import InputField from '../components/InputField';
import { NumericFormat, PatternFormat } from 'react-number-format';
import { UserCircleIcon, BuildingOfficeIcon, HashIcon, MapTrifoldIcon, MapPinIcon, IdentificationCardIcon, PhoneIcon, WarningCircleIcon, CalendarDotsIcon, CalendarPlusIcon, CalendarXIcon, FilePdfIcon, PhoneListIcon, PlusCircleIcon, CurrencyDollarIcon} from "@phosphor-icons/react";
import { useEffect, useState } from 'react';
import SelectField from '../components/SelectField';
import TagField from '../components/TagField';
import { adicionarLinha } from '../utils/adicionarLinha'
import { formatarData, formatarDataInput } from '../utils/formatacoes';
import { gerarPDFRoaming } from '../utils/pdf/roamingPDF';

const periodo = [
    {value: 'Mensal', label: 'Mensal'},
    {value: 'Diária', label: 'Diária'}
]


function Roaming() {
    const [erro, setErro] = useState('');

    const [dados, setDados] = useState({
        empresa:"",
        cnpj:"",
        endereco:"",
        cep:"",
        cidade:"",
        responsavel:"",
        cpf:"",
        linha:"",
        periodo:"",
        valor:"",
        dataInicio:"",
        dataFim:"",
        linhasAdicionadas:[],
    })

    useEffect(() => {
        if (dados.periodo === 'Mensal' && dados.dataInicio) {
            const [dia, mes, ano] = dados.dataInicio.split('/');
            const dataInicio = new Date(ano, mes - 1, dia - 1);
            dataInicio.setMonth(dataInicio.getMonth() + 24);
            const dataFim = formatarData(dataInicio.toISOString().split('T')[0]);
            setDados((prev) => ({ ...prev, dataFim }));
        }

        if (dados.periodo === 'Diária') {
            setDados((prev) => ({ ...prev, dataFim: "" }));
        }
    }, [dados.periodo, dados.dataInicio])

    const hoje = new Date().toISOString().split('T')[0];

    function debug() {
        console.log(dados)
        console.table(dados.linhasAdicionadas)
    }

    return (
        <div className='bg-white flex items-center flex-col py-6'>
            <form className='mx-auto' action="">
                <fieldset className="grid grid-cols-4 gap-4 space-y-4 mb-12">
                    <legend className='mb-4 font-black text-[#394A77] text-xl'>Termo de Contratação - Roaming Internacional VIVO</legend>

                    <InputField
                    label="Empresa"
                    icone={BuildingOfficeIcon }
                    size="col-span-3"
                    placeholder='Associado'
                    value={dados.empresa}
                    onChange={(e) => setDados((prev) => ({ ...prev, empresa: e.target.value }))}
                    />

                    <PatternFormat
                    label="CNPJ"
                    icone={HashIcon }
                    customInput={InputField}
                    format="##.###.###/####-##"
                    placeholder="00.000.000/0000-00"
                    value={dados.cnpj}
                    onValueChange={(values) => setDados((prev) => ({ ...prev, cnpj: values.formattedValue }))}
                    />

                    <InputField 
                    label="Endereço"
                    icone={MapPinIcon }
                    size="col-span-2"
                    value={dados.endereco}
                    onChange={(e) => setDados((prev) => ({ ...prev, endereco: e.target.value }))}
                    />

                    <PatternFormat
                    label="CEP"
                    icone={MapPinIcon }
                    customInput={InputField}
                    format="##.###-###"
                    value={dados.cep}
                    onValueChange={(values) => setDados((prev) => ({ ...prev, cep: values.formattedValue }))}
                    />

                    <InputField 
                    label="Cidade"
                    icone={MapTrifoldIcon }
                    value={dados.cidade}
                    onChange={(e) => setDados((prev) => ({ ...prev, cidade: e.target.value }))}
                    />
                    
                    <InputField 
                    label="Responsável"
                    icone={UserCircleIcon}
                    size="col-span-2"
                    type='text'
                    placeholder='Proprietário'
                    onChange={(e) => setDados((prev) => ({ ...prev, responsavel: e.target.value }))}
                    />

                    <PatternFormat 
                    label="CPF"
                    icone={IdentificationCardIcon }
                    size="col-span-2"
                    customInput={InputField}
                    type='text'
                    format="###.###.###-##"
                    value={dados.cpf}
                    onChange={(e) => setDados((prev) => ({ ...prev, cpf: e.target.value }))}
                    />

                </fieldset>
                
                <fieldset className="grid grid-cols-3 gap-3 space-y-4 mb-8">
                    <legend className='mb-4 font-black text-[#394A77] text-xl'>Dados da Contratação</legend>

                    <div className='space-y-2'>
                        <PatternFormat
                        label="Linha"
                        format="(##) #####-####"
                        value={dados.linha}
                        icone={PhoneIcon}
                        onValueChange={(values) => setDados((prev) => ({ ...prev, linha: values.formattedValue }))}
                        customInput={InputField}
                        placeholder="(11) 99999-9999"
                        button
                        onButton={() => adicionarLinha(dados, setDados, setErro)}
                        onKeyDown={(e) => {
                            if (e.key === 'Enter') adicionarLinha(dados, setDados, setErro)
                        }}
                        />
                        <span className={`text-red-500 text-sm flex items-center gap-1 ${erro ? 'visible' : 'invisible'}`}>
                            <WarningCircleIcon size={16} /> {erro || "placeholder"}
                        </span>
                    </div>

                    <NumericFormat 
                    label="Valor"
                    icone={CurrencyDollarIcon}
                    customInput={InputField}
                    prefix="R$"
                    thousandSeparator="."
                    decimalSeparator=","
                    decimalScale={2}
                    fixedDecimalScale
                    value={dados.valor}
                    onChange={(e) => setDados((prev) => ({ ...prev, valor: e.target.value }))}
                    />

                    <SelectField 
                    label="Período"
                    options={periodo}
                    icone={CalendarDotsIcon}
                    onChange={(e) => setDados({ ...dados, periodo: e.target.value })}
                    />

                    <InputField 
                    label="Data Início"
                    icone={CalendarPlusIcon }
                    value={formatarDataInput(dados.dataInicio)}
                    type="date"
                    min={hoje}
                    onChange={(e) => setDados({ ...dados, dataInicio: formatarData(e.target.value) })}
                    />

                    <InputField 
                    label="Data Fim"
                    icone={CalendarXIcon }
                    type="date"
                    value={formatarDataInput(dados.dataFim)}
                    min={formatarDataInput(dados.dataInicio)}
                    disabled={dados.periodo !== 'Diária'}
                    onChange={(e) => setDados({ ...dados, dataFim: formatarData(e.target.value) })}
                    />

                </fieldset>

                <fieldset className="grid grid-cols-4 gap-5 space-y-4 mb-12">
                    <legend className='mb-4 font-black text-[#394A77] text-xl'>Pré-visualização</legend>

                    <TagField
                    label="Linhas Selecionadas"
                    icone={PhoneListIcon}
                    size="col-span-4"
                    itens={dados.linhasAdicionadas}
                    onRemover={(item) => setDados((prev) => ({
                        ...prev,
                        linhasAdicionadas: prev.linhasAdicionadas.filter((numero) => numero !== item)

                    }))}
                    />
                </fieldset>

            <button type="button" onClick={() => gerarPDFRoaming(dados)} className="flex items-center hover:scale-105 transition-all hover: border-3 rounded-xl text-lg px-8 py-2 cursor-pointer gap-2 text-[#343E6A] border-[#343E6A] hover:bg-[#e7e7e7] bg-[#F7F7F7] active:bg-[#d8d6d6] active:scale-95 font-bold">
                <FilePdfIcon size={32} /> 
                <p>Gerar PDF</p>
            </button>
            </form>
            
        </div>
    )
}

export default Roaming