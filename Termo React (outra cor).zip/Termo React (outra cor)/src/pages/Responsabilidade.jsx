import SelectField from '../components/SelectField';
import TagField from '../components/TagField';
import InputField from '../components/InputField';
import RadioField from '../components/RadioField';
import { adicionarLinha } from '../utils/adicionarLinha'
import {AtIcon, KeyIcon, DeviceMobileIcon, HashIcon, MapTrifoldIcon, HeadphonesIcon, PhoneCallIcon, PhoneIcon, WarningCircleIcon, ListIcon, FilePdfIcon, PhoneListIcon, PlusCircleIcon, CheckSquareIcon, CurrencyDollarIcon, QuestionIcon } from "@phosphor-icons/react";
import { useState, useEffect } from 'react';
import { NumericFormat, PatternFormat } from 'react-number-format';
import { gerarPDFResponsabilidade } from '../utils/pdf/responsabilidadePDF';

function Responsabilidade() {


    const [dados, setDados] = useState({
        aparelho:"",
        imei:"",
        estado:"",
        acessorios:"",
        cep:"",
        cidade:"",
        responsavel:"",
        cpf:"",
        linha:"",
        motivo:"",
        multa:"",
        linhasAdicionadas:[],
    })

    return(
        <div className='bg-white flex items-center flex-col py-6'>
            <form className='mx-auto' action="">
                <fieldset className="grid grid-cols-4 gap-4 space-y-4 mb-12">
                    <legend className='mb-12 font-black text-[#394A77] text-xl'>TERMO DE RESPONSABILIDADE PELA GUARDA E USO DE EQUIPAMENTO DE TRABALHO</legend>

                    <InputField 
                    label="Modelo do Equipamento"
                    icone={DeviceMobileIcon }
                    size="col-span-3"
                    placeholder='Aparelho'
                    value={dados.empresa}
                    onChange={(e) => setDados((prev) => ({ ...prev, aparelho: e.target.value }))}
                    />

                    <PatternFormat
                    label="IMEI"
                    icone={HashIcon }
                    customInput={InputField}
                    format="###############"
                    placeholder="xxxxxxxxxxxxxxx"
                    value={dados.imei}
                    onValueChange={(values) => setDados((prev) => ({ ...prev, imei: values.formattedValue }))}
                    />

                    <NumericFormat 
                    label="Valor"
                    icone={CurrencyDollarIcon}
                    customInput={InputField}
                    prefix="R$"
                    size="col-span-2"
                    thousandSeparator="."
                    decimalSeparator=","
                    decimalScale={2}
                    fixedDecimalScale
                    value={dados.valor}
                    onChange={(e) => setDados((prev) => ({ ...prev, valor: e.target.value }))}
                    />

                    <InputField 
                    label="Acessórios"
                    icone={HeadphonesIcon }
                    placeholder="Carregador"
                    value={dados.acessorios}
                    onChange={(e) => setDados((prev) => ({ ...prev, acessorios: e.target.value }))}
                    />

                   <RadioField
                        label="Estado do Aparelho"
                        icone={HeadphonesIcon}
                        value={dados.estado}
                        onChange={(e) => setDados((prev) => ({...prev, estado: e.target.value }))}
                    />

                </fieldset>

                <fieldset className="grid grid-cols-4 gap-4 space-y-4 mb-12">
                    <InputField 
                    label="E-mail"
                    icone={AtIcon }
                    size="col-span-2"
                    type='text'
                    placeholder='E-mail de backup WhatsApp'
                    onChange={(e) => setDados((prev) => ({ ...prev, email: e.target.value }))}
                    />

                    <InputField 
                    label="Senha"
                    icone={KeyIcon }
                    size="col-span-2"
                    type='text'
                    placeholder='Senha do e-mail'
                    onChange={(e) => setDados((prev) => ({ ...prev, senha: e.target.value }))}
                    />
                </fieldset>

                <fieldset className="grid grid-cols-4 gap-4 space-y-4 mb-12">
                    <PatternFormat 
                    label="Linha Corporativa"
                    icone={PhoneCallIcon  }
                    size="col-span-2"
                    customInput={InputField}
                    type='text'
                    format="(##) #####-####"
                    placeholder="(16) 99999-9999"
                    value={dados.telefone}
                    onChange={(e) => setDados((prev) => ({ ...prev, telefone: e.target.value }))}
                    />

                    <PatternFormat 
                    label="PIN - WhatsApp"
                    icone={PhoneCallIcon }
                    size="col-span-2"
                    customInput={InputField}
                    type='text'
                    format="######"
                    placeholder="010101"
                    value={dados.whats}
                    onChange={(e) => setDados((prev) => ({ ...prev, whats: e.target.value }))}
                    />
                </fieldset>

                <button type="button" onClick={() => gerarPDFResponsabilidade(dados)} className="flex items-center hover:scale-105 transition-all hover: border-3 rounded-xl text-lg px-8 py-2 cursor-pointer gap-2 text-[#343E6A] border-[#343E6A] hover:bg-[#e7e7e7] bg-[#F7F7F7] active:bg-[#d8d6d6] active:scale-95 font-bold">
                    <FilePdfIcon size={32} /> 
                    <p>Gerar PDF</p>
                </button>
            </form>
        </div>
    )   
}

export default Responsabilidade