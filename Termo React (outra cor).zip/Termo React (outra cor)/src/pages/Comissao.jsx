
function Comissao () {
    return (
        <div className='bg-white flex items-center flex-col'>
            <p className="font-semibold text-slate-600 text-xl">Comissão</p>
        </div>
    )
}

export default Comissao