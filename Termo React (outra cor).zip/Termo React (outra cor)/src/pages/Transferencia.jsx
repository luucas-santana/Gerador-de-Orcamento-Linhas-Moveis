import InputField from '../components/InputField';
import { NumericFormat, PatternFormat } from 'react-number-format';
import { UserCircleIcon, BuildingOfficeIcon, HashIcon, MapTrifoldIcon, MapPinIcon, IdentificationCardIcon, PhoneIcon, WarningCircleIcon, CalendarDotsIcon, CalendarPlusIcon, CalendarXIcon, FilePdfIcon, PhoneListIcon, PlusCircleIcon, CurrencyDollarIcon} from "@phosphor-icons/react";
import { useEffect, useState } from 'react';
import SelectField from '../components/SelectField';
import TagField from '../components/TagField';
import { adicionarLinha } from '../utils/adicionarLinha'
import { formatarData, formatarDataInput } from '../utils/formatacoes';
import { gerarPDFTransferencia } from '../utils/pdf/transferenciaPDF';

function Roaming() {
    const [erro, setErro] = useState('');

    const [dados, setDados] = useState({
        empresaDoador:"",
        cnpjDoador:"",
        enderecoDoador:"",
        cepDoador:"",
        cidadeDoador:"",
        responsavelDoador:"",
        cpfDoador:"",
        linha:"",
        linhasAdicionadas:[],
        empresaReceptor:"",
        cnpjReceptor:"",
        enderecoReceptor:"",
        cepReceptor:"",
        cidadeReceptor:"",
        responsavelReceptor:"",
        cpfReceptor:"",
    })

    const hoje = new Date().toISOString().split('T')[0];

    function debug() {
        console.log(dados)
        console.table(dados.linhasAdicionadas)
    }

    return (
        <div className='bg-white flex items-center flex-col py-6'>
            <form className='mx-auto' action="">
                <legend className='mb-4 font-black text-[#394A77] text-xl'>Termo de Transferência de Titularidade Interna</legend>
                <fieldset className="grid grid-cols-4 gap-4 space-y-4 mb-12">
                <legend className='mb-4 font-black text-[#394A77] text-xl'>Dados do Cedente</legend>

                    <InputField 
                    label="Empresa"
                    icone={BuildingOfficeIcon }
                    size="col-span-3"
                    placeholder='Associado'
                    value={dados.empresaDoador}
                    onChange={(e) => setDados((prev) => ({ ...prev, empresaDoador: e.target.value }))}
                    />

                    <PatternFormat
                    label="CNPJ"
                    icone={HashIcon }
                    customInput={InputField}
                    format="##.###.###/####-##"
                    placeholder="00.000.000/0000-00"
                    value={dados.cnpjDoador}
                    onValueChange={(values) => setDados((prev) => ({ ...prev, cnpjDoador: values.formattedValue }))}
                    />

                    <InputField 
                    label="Endereço"
                    icone={MapPinIcon }
                    size="col-span-2"
                    value={dados.enderecoDoador}
                    onChange={(e) => setDados((prev) => ({ ...prev, enderecoDoador: e.target.value }))}
                    />

                    <PatternFormat
                    label="CEP"
                    icone={MapPinIcon }
                    customInput={InputField}
                    format="##.###-###"
                    value={dados.cepDoador}
                    onValueChange={(values) => setDados((prev) => ({ ...prev, cepDoador: values.formattedValue }))}
                    />

                    <InputField 
                    label="Cidade"
                    icone={MapTrifoldIcon }
                    value={dados.cidadeDoador}
                    onChange={(e) => setDados((prev) => ({ ...prev, cidadeDoador: e.target.value }))}
                    />
                    
                    <InputField 
                    label="Responsável"
                    icone={UserCircleIcon}
                    size="col-span-2"
                    type='text'
                    placeholder='Proprietário'
                    onChange={(e) => setDados((prev) => ({ ...prev, responsavelDoador: e.target.value }))}
                    />

                    <PatternFormat 
                    label="CPF"
                    icone={IdentificationCardIcon }
                    size="col-span-2"
                    customInput={InputField}
                    type='text'
                    format="###.###.###-##"
                    value={dados.cpf}
                    onChange={(e) => setDados((prev) => ({ ...prev, cpfDoador: e.target.value }))}
                    />

                </fieldset>

                <fieldset className="grid grid-cols-4 gap-4 mb-12">
                <legend className='mb-4 font-black text-[#394A77] text-xl'>Dados do Cessionário</legend>

                    <InputField 
                    label="Empresa"
                    icone={BuildingOfficeIcon }
                    size="col-span-3"
                    placeholder='Associado'
                    value={dados.empresa}
                    onChange={(e) => setDados((prev) => ({ ...prev, empresaReceptor: e.target.value }))}
                    />

                    <PatternFormat
                    label="CNPJ"
                    icone={HashIcon }
                    customInput={InputField}
                    format="##.###.###/####-##"
                    placeholder="00.000.000/0000-00"
                    value={dados.cnpj}
                    onValueChange={(values) => setDados((prev) => ({ ...prev, cnpjReceptor: values.formattedValue }))}
                    />

                    <InputField 
                    label="Endereço"
                    icone={MapPinIcon }
                    size="col-span-2"
                    value={dados.endereco}
                    onChange={(e) => setDados((prev) => ({ ...prev, enderecoReceptor: e.target.value }))}
                    />

                    <PatternFormat
                    label="CEP"
                    icone={MapPinIcon }
                    customInput={InputField}
                    format="##.###-###"
                    value={dados.cep}
                    onValueChange={(values) => setDados((prev) => ({ ...prev, cepReceptor: values.formattedValue }))}
                    />

                    <InputField 
                    label="Cidade"
                    icone={MapTrifoldIcon }
                    value={dados.cidade}
                    onChange={(e) => setDados((prev) => ({ ...prev, cidadeReceptor: e.target.value }))}
                    />
                    
                    <InputField 
                    label="Responsável"
                    icone={UserCircleIcon}
                    size="col-span-2"
                    type='text'
                    placeholder='Proprietário'
                    onChange={(e) => setDados((prev) => ({ ...prev, responsavelReceptor: e.target.value }))}
                    />

                    <PatternFormat 
                    label="CPF"
                    icone={IdentificationCardIcon }
                    size="col-span-2"
                    customInput={InputField}
                    type='text'
                    format="###.###.###-##"
                    value={dados.cpf}
                    onChange={(e) => setDados((prev) => ({ ...prev, cpfReceptor: e.target.value }))}
                    />

                </fieldset>
                
                <fieldset className="grid grid-cols-2 gap-5 space-y-4 mb-8">
                    <legend className='mb-4 font-black text-[#394A77] text-xl'>Linhas para Transferência</legend>

                    <div className='space-y-2'>
                        <PatternFormat
                        label="Linha"
                        format="(##) #####-####"
                        value={dados.linha}
                        icone={PhoneIcon}
                        onValueChange={(values) => setDados((prev) => ({ ...prev, linha: values.formattedValue }))}
                        customInput={InputField}
                        placeholder="(11) 99999-9999"
                        button
                        onButton={() => adicionarLinha(dados, setDados, setErro)}
                        onKeyDown={(e) => {
                            if (e.key === 'Enter') adicionarLinha(dados, setDados, setErro)
                        }}
                        />
                        <span className={`text-red-500 text-sm flex items-center gap-1 ${erro ? 'visible' : 'invisible'}`}>
                            <WarningCircleIcon size={16} /> {erro || "placeholder"}
                        </span>
                    </div>

                    <TagField
                    label="Linhas Selecionadas"
                    icone={PhoneListIcon}
                    itens={dados.linhasAdicionadas}
                    onRemover={(item) => setDados((prev) => ({
                        ...prev,
                        linhasAdicionadas: prev.linhasAdicionadas.filter((numero) => numero !== item)

                    }))}
                    />

                </fieldset>

            <button type="button" onClick={() => gerarPDFTransferencia(dados)} className="flex items-center hover:scale-105 transition-all hover: border-3 rounded-xl text-lg px-8 py-2 cursor-pointer gap-2 text-[#343E6A] border-[#343E6A] hover:bg-[#e7e7e7] bg-[#F7F7F7] active:bg-[#d8d6d6] active:scale-95 font-bold">
                <FilePdfIcon size={32} /> 
                <p>Gerar PDF</p>
            </button>
            </form>
            
        </div>
    )
}

export default Roaming