import SelectField from '../components/SelectField';
import TagField from '../components/TagField';
import InputField from '../components/InputField';
import { adicionarLinha } from '../utils/adicionarLinha'
import { UserCircleIcon, BuildingOfficeIcon, HashIcon, MapTrifoldIcon, MapPinIcon, IdentificationCardIcon, PhoneIcon, WarningCircleIcon, ListIcon, FilePdfIcon, PhoneListIcon, PlusCircleIcon, CurrencyDollarIcon, QuestionIcon } from "@phosphor-icons/react";
import { useState, useEffect } from 'react';
import { NumericFormat, PatternFormat } from 'react-number-format';
import { gerarPDFCancelamento } from '../utils/pdf/cancelamentoPDF';

const motivo = [
    {value: 'Sem utilização', label: 'Sem utilização'},
    {value: 'Encerramento das Atividades', label: 'Encerramento das Atividades'},
    {value: 'Solicitação', label: 'Solicitação'},
]

function Cancelamento() {
    const [erro, setErro] = useState('');
    
    const [dados, setDados] = useState({
        empresa:"",
        cnpj:"",
        endereco:"",
        cep:"",
        cidade:"",
        responsavel:"",
        cpf:"",
        linha:"",
        motivo:"",
        multa:"",
        linhasAdicionadas:[],
    })

    const hoje = new Date().toISOString().split('T')[0];

    function debug() {
        console.log(dados)
        console.table(dados.linhasAdicionadas)
    }

    return (
        <div className='bg-white flex items-center flex-col py-6'>
            <form className='mx-auto' action="">
                <fieldset className="grid grid-cols-4 gap-4 space-y-4 mb-12">
                    <legend className='mb-4 font-black text-[#394A77] text-xl'>Termo de Cancelamento de Linha</legend>

                    <InputField 
                    label="Empresa"
                    icone={BuildingOfficeIcon }
                    size="col-span-3"
                    placeholder='Associado'
                    value={dados.empresa}
                    onChange={(e) => setDados((prev) => ({ ...prev, empresa: e.target.value }))}
                    />

                    <PatternFormat
                    label="CNPJ"
                    icone={HashIcon }
                    customInput={InputField}
                    format="##.###.###/####-##"
                    placeholder="00.000.000/0000-00"
                    value={dados.cnpj}
                    onValueChange={(values) => setDados((prev) => ({ ...prev, cnpj: values.formattedValue }))}
                    />

                    <InputField 
                    label="Endereço"
                    icone={MapPinIcon }
                    size="col-span-2"
                    value={dados.endereco}
                    onChange={(e) => setDados((prev) => ({ ...prev, endereco: e.target.value }))}
                    />

                    <PatternFormat
                    label="CEP"
                    icone={MapPinIcon}
                    customInput={InputField}
                    format="#####-###"
                    value={dados.cep}
                    onValueChange={(values) => setDados((prev) => ({ ...prev, cep: values.formattedValue }))}
                    />

                    <InputField 
                    label="Cidade"
                    icone={MapTrifoldIcon }
                    value={dados.cidade}
                    onChange={(e) => setDados((prev) => ({ ...prev, cidade: e.target.value }))}
                    />
                    
                    <InputField 
                    label="Responsável"
                    icone={UserCircleIcon}
                    size="col-span-2"
                    type='text'
                    placeholder='Proprietário'
                    onChange={(e) => setDados((prev) => ({ ...prev, responsavel: e.target.value }))}
                    />

                    <PatternFormat 
                    label="CPF"
                    icone={IdentificationCardIcon }
                    size="col-span-2"
                    customInput={InputField}
                    type='text'
                    format="###.###.###-##"
                    value={dados.cpf}
                    onChange={(e) => setDados((prev) => ({ ...prev, cpf: e.target.value }))}
                    />

                </fieldset>

                <fieldset className="grid grid-cols-3 gap-5 space-y-4 mb-8">
                    <legend className='mb-4 font-black text-[#394A77] text-xl'>Dados do Cancelamento</legend>

                    <div className='space-y-2'>
                        <PatternFormat
                        label="Linha"
                        format="(##) #####-####"
                        value={dados.linha}
                        icone={PhoneIcon}
                        onValueChange={(values) => setDados((prev) => ({ ...prev, linha: values.formattedValue }))}
                        customInput={InputField}
                        placeholder="(11) 99999-9999"
                        button
                        onButton={() => adicionarLinha(dados, setDados, setErro)}
                        onKeyDown={(e) => {
                            if (e.key === 'Enter') adicionarLinha(dados, setDados, setErro)
                        }}
                        />
                        <span className={`text-red-500 text-sm flex items-center gap-1 ${erro ? 'visible' : 'invisible'}`}>
                            <WarningCircleIcon size={16} /> {erro || "placeholder"}
                        </span>
                    </div>

                    <SelectField 
                    label="Motivo"
                    options={motivo}
                    icone={QuestionIcon }
                    onChange={(e) => setDados({ ...dados, motivo: e.target.value })}
                    />

                    <NumericFormat 
                    label="Multa"
                    icone={CurrencyDollarIcon }
                    customInput={InputField}
                    prefix="R$"
                    thousandSeparator="."
                    decimalSeparator=","
                    fixedDecimalScale
                    placeholder="Sem multa"
                    value={dados.valor}
                    onChange={(e) => setDados((prev) => ({ ...prev, multa: e.target.value }))}
                    />

                </fieldset>

                <fieldset className="grid grid-cols-4 gap-5 space-y-4 mb-12">
                    <legend className='mb-4 font-black text-[#394A77] text-xl'>Pré-visualização</legend>

                    <TagField
                    label="Linhas Selecionadas"
                    icone={PhoneListIcon}
                    size="col-span-4"
                    itens={dados.linhasAdicionadas}
                    onRemover={(item) => setDados((prev) => ({
                        ...prev,
                        linhasAdicionadas: prev.linhasAdicionadas.filter((numero) => numero !== item)

                    }))}
                    />
                </fieldset>

                <button type="button" onClick={() => gerarPDFCancelamento(dados)} className="flex items-center hover:scale-105 transition-all hover: border-3 rounded-xl text-lg px-8 py-2 cursor-pointer gap-2 text-[#343E6A] border-[#343E6A] hover:bg-[#e7e7e7] bg-[#F7F7F7] active:bg-[#d8d6d6] active:scale-95 font-bold">
                    <FilePdfIcon size={32} /> 
                    <p>Gerar PDF</p>
                </button>
            </form>
        </div>
    )
}

export default Cancelamento