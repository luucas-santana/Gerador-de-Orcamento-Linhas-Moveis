import Inicio from "./pages/Inicio"
import Sidebar from "./components/Sidebar"
import Cancelamento from "./pages/Cancelamento";
import Roaming from "./pages/Roaming";
import Transferencia from "./pages/Transferencia"
import Responsabilidade from "./pages/Responsabilidade"
import { Routes, Route } from 'react-router';
import Comissao from "./pages/Comissao"



function App() {
  return (
    <div className="min-h-screen bg-slate-200 flex">
      <aside>
        <Sidebar />
      </aside>

      <main className="w-full">
        <Routes>
          <Route path="/" element={<Inicio />}/>
          <Route path="/cancelamento" element={<Cancelamento />}/>
          <Route path="/roaming" element={<Roaming />}/>
          <Route path="/transferencia" element={<Transferencia />}/>
          <Route path="/comissao" element={<Comissao />}/>
          <Route path="/responsabilidade" element={<Responsabilidade />}/>
        </Routes>

      

      </main>
    </div>
  )
}

export default App