export const formatarData = (data) => {
    const [ano, mes, dia] = data.split('-');
    return `${dia}/${mes}/${ano}`;
}

export const formatarDataInput = (data) => {
    if (!data) return "";
    const [dia, mes, ano] = data.split('/');
    return `${ano}-${mes}-${dia}`;
}
