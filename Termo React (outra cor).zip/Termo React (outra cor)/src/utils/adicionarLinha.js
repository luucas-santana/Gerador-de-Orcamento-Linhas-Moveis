export const validarLinha = (value) => {
    const cleaned = value.replace(/\D/g, '');
    const regex = /^([1-9]{2})(9[1-9]\d{6,7})$/;
    return regex.test(cleaned);
}

export const adicionarLinha = (dados, setDados, setErro) => {
    const apenasDigitos = dados.linha.replace(/\D/g, '');

    if (!apenasDigitos) {
        setErro("Digite o número");
        return;
    }

    if (dados.linhasAdicionadas.includes(dados.linha)) {
        setErro("Linha já adicionada")
        return;
    }

    if (dados.linha && !validarLinha(dados.linha)) {
        setErro("Verifique o número");
        return;
    }

    setErro('');
    setDados((prev) => ({
        ...prev,
        linhasAdicionadas: [...prev.linhasAdicionadas, dados.linha],
        linha: ""
    }));
}