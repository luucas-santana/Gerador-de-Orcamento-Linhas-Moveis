import { jsPDF } from "jspdf";
import { JakartaBold } from "../pdf/fonts/JakartaBold-bold"
import { JakartaNormal } from "../pdf/fonts/Jakarta-normal"
import { cabecalho, tituloPrincipal, data, responsavel, rodape, inputsAssociadosReceptor, inputsAssociadosDoador, responsavelReceptor, responsavelDoador} from "./ConfigPDF";

export const gerarPDFTransferencia = (dados) => {
    const doc = new jsPDF();

    const medidas = {
        larguraPag: doc.internal.pageSize.getWidth(),
        alturaPag: doc.internal.pageSize.getHeight(),
        yOffset: 15
    };

    JakartaNormal(doc);
    JakartaBold(doc);


    cabecalho(doc, medidas, "Transferência de Titularidade Interna");
    medidas.yOffset += 24;
    tituloPrincipal(doc, "Associado Cedente", medidas);
    inputsAssociadosDoador(doc, dados, medidas);
    medidas.yOffset += 2;
    tituloPrincipal(doc, "Associado Cessionário", medidas);
    inputsAssociadosReceptor(doc, dados, medidas);
    
    tituloPrincipal(doc, "Transferência de Titularidade Interna", medidas);
    doc.setDrawColor(15, 118, 110);
    doc.setLineWidth(0.8);
    doc.setFillColor(255, 255, 255);
    doc.roundedRect(10, medidas.yOffset + 6, 190, 60, 2, 2, 'FD')
    
    doc.setFontSize(13);
    doc.setFillColor(226, 232, 240);
    doc.setTextColor(15, 118, 110);
    doc.setFont("Jakarta", "bold");
    doc.text('Autorização', 13, medidas.yOffset + 12);
    
    doc.setFontSize(10);
    doc.setTextColor(75, 85, 99);
    
    doc.setFont("Jakarta", "normal");
    doc.text('Pelo presente Termo de Transferência de Titularidade Interna, as partes acordam a transferência das responsabilidades e obrigações relativas à(s) linha(s) relacionada(s) abaixo. Declaro estar ciente de que será cobrado, no boleto ACISC, o valor proporcional até a conclusão do processo de transferência de titularidade interna, conforme o período do ciclo da operadora.', 13, medidas.yOffset + 18, { maxWidth: 180, align: 'justify', lineHeightFactor: 1.5});
    
    doc.setDrawColor(15, 118, 110);
    doc.setLineWidth(0.8);
    doc.setFillColor(255, 255, 255);
    doc.roundedRect(10, medidas.yOffset + 39, 190, 0, 2, 2, 'D')
    
    doc.setFont("Jakarta", "bold");
    doc.text('Linha(s):', 13, medidas.yOffset + 46);
    doc.setFont("Jakarta", "normal");
    doc.setTextColor(75, 85, 99);
    const listaLinhas = dados?.linhasAdicionadas || []; 

    for (let i = 0; i < listaLinhas.length; i += 5) {
        doc.text(listaLinhas.slice(i, i + 5).join(',  '), 29, medidas.yOffset + 46); 
        medidas.yOffset += 4;
    }
    
    doc.setFontSize(7);
    doc.setTextColor(75, 85, 99);
    
    data(doc, medidas, 222)
    responsavelDoador(doc, medidas, dados)
    responsavelReceptor(doc, medidas, dados)
    rodape(doc, medidas, dados)


    doc.output('dataurlnewwindow');
};