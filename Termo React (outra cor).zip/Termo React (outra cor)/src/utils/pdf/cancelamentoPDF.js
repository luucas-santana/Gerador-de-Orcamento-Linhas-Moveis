import { jsPDF } from "jspdf";
import { JakartaBold } from "../pdf/fonts/JakartaBold-bold"
import { JakartaNormal } from "../pdf/fonts/Jakarta-normal"
import { cabecalho, tituloPrincipal, data, responsavel, rodape,inputsAssociados } from "./ConfigPDF";

export const gerarPDFCancelamento = (dados) => {
    const doc = new jsPDF();

    const nome_meses = [
        "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", 
        "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
    ];

    const numero_meses = [
        "01", "02", "03", "04", "05", "06", 
        "07", "08", "09", "10", "11", "12"
    ];
    const hoje = new Date();

    const ano = hoje.getFullYear();
    const mes = hoje.getMonth();
    const dia = String(hoje.getDate()).padStart(2, '0');

    let dataPrimeiroBoleto
    let cobrancaPrimeiroBoleto
    let dataSegundoBoleto
    let cobrancaSegundoBoleto

    const diaInicioCiclo = 25
    const diaFimCiclo = 24

    const medidas = {
        larguraPag: doc.internal.pageSize.getWidth(),
        alturaPag: doc.internal.pageSize.getHeight(),
        yOffset: 15
    };

    JakartaNormal(doc);
    JakartaBold(doc);

    cabecalho(doc, medidas, "Cancelamento de Linha");
    inputsAssociados(doc, dados, medidas);
    tituloPrincipal(doc, "Termo de Cancelamento de Linha", medidas);


    doc.setDrawColor(15, 118, 110);
    doc.setLineWidth(0.8);
    doc.setFillColor(255, 255, 255);
    doc.roundedRect(10, medidas.yOffset + 6, 190, 100, 2, 2, 'FD')
    
    doc.setFontSize(13);
    doc.setFillColor(226, 232, 240);
    doc.setTextColor(15, 118, 110);
    doc.setFont("Jakarta", "bold");
    doc.text('Detalhes do Cancelamento', 13, medidas.yOffset + 13);
    doc.setFont("Jakarta", "normal")
    doc.setFontSize(8);
    doc.text('O cancelamento resulta na perda definitiva do número', 13, medidas.yOffset + 17);
    
    doc.setFontSize(11);
    doc.setTextColor(75, 85, 99);
    
    doc.setFont("Jakarta", "bold");
    doc.text('Motivo:', 17, medidas.yOffset + 24);
    doc.setFont("Jakarta", "normal");
    doc.text(`${dados.motivo}`, 33, medidas.yOffset + 24);
    
   if (dados.multa) {
        doc.setFont("Jakarta", "bold");
        doc.text('Multa:', 17, medidas.yOffset + 32);
        doc.setFont("Jakarta", "normal");
        doc.text(`${dados.multa}`, 30, medidas.yOffset + 32);

        medidas.yOffset += 8;
    }
    
    doc.setFont("Jakarta", "bold");
    doc.text('Linhas:', 17, medidas.yOffset + 32);
    doc.setFont("Jakarta", "normal");
    const listaLinhas = dados?.linhasAdicionadas || []; 

    for (let i = 0; i < listaLinhas.length; i += 5) {
        doc.text(listaLinhas.slice(i, i + 5).join(',  '), 31, medidas.yOffset + 32); 
        medidas.yOffset += 4;
    }
    
    doc.setDrawColor(15, 118, 110);
    doc.setLineWidth(0.8);
    doc.setFillColor(255, 255, 255);
    doc.roundedRect(10, medidas.yOffset + 40, 190, 0, 2, 2, 'D')

    doc.setFontSize(13);
    doc.setFillColor(226, 232, 240);
    doc.setTextColor(15, 118, 110);
    doc.setFont("Jakarta", "bold");
    doc.text('Boletos ACISC', 13, medidas.yOffset + 48);

    doc.setFontSize(10);
    doc.setTextColor(75, 85, 99);

    if (dia >= diaInicioCiclo){
        let mesPrimeiroBoleto
        let anoPrimeiroBoleto
        let anoSegundoBoleto
        let mesSegundoBoleto
        let mesCicloAtual
 

        let primeiroMes = new Date(ano, mes, 1);
        primeiroMes.setMonth(primeiroMes.getMonth() + 1)
        mesPrimeiroBoleto = primeiroMes.getMonth();
        anoPrimeiroBoleto = primeiroMes.getFullYear();

        let mesCicloPassado = new Date(ano, mes, 1);
        mesCicloPassado.setMonth(mesCicloPassado.getMonth() - 1)
        mesCicloAtual = mesCicloPassado.getMonth()
        

        let segundoBoleto = new Date(ano, mes, 1)
        segundoBoleto.setMonth(segundoBoleto.getMonth() + 2);
        mesSegundoBoleto = segundoBoleto.getMonth();
        anoSegundoBoleto = segundoBoleto.getFullYear();

        
        dataPrimeiroBoleto = `Boleto ${nome_meses[mesPrimeiroBoleto]}/${anoPrimeiroBoleto}`
        cobrancaPrimeiroBoleto = `Cobrança total referente ao ciclo da operadora - ${diaInicioCiclo}/${numero_meses[mesCicloAtual]} até ${diaFimCiclo}/${numero_meses[mes]}`
        
        dataSegundoBoleto = `Boleto ${nome_meses[mesSegundoBoleto]}/${anoSegundoBoleto}`
        cobrancaSegundoBoleto = `Cobrança parcial: ${diaInicioCiclo}/${numero_meses[mes]} até a conclusão do cancelamento`

    } else {
        let mesPrimeiroBoleto
        let anoPrimeiroBoleto
        let anoSegundoBoleto
        let mesSegundoBoleto
        let mesCicloAtual

        let dataInicio = new Date(ano, mes, 1);
        dataInicio.setMonth(dataInicio.getMonth() + 1);

        mesPrimeiroBoleto = dataInicio.getMonth();
        anoPrimeiroBoleto = dataInicio.getFullYear();

        let segundoBoleto = new Date(ano, mes, 1)
        segundoBoleto.setMonth(segundoBoleto.getMonth() + 2);

        mesSegundoBoleto = segundoBoleto.getMonth();
        anoSegundoBoleto = segundoBoleto.getFullYear();

        let mesFimSegundoBoleto = new Date(ano, mes, 1)
        mesFimSegundoBoleto.setMonth(mesFimSegundoBoleto.getMonth() - 1);
        mesCicloAtual = mesFimSegundoBoleto.getMonth();

        dataPrimeiroBoleto = `Boleto ${nome_meses[mesPrimeiroBoleto]}/${anoPrimeiroBoleto}`
        cobrancaPrimeiroBoleto = `Cobrança parcial: Dia ${diaInicioCiclo}/${numero_meses[mesCicloAtual]} até conclusão do cancelamento`
        
        dataSegundoBoleto = `Boleto ${nome_meses[mesSegundoBoleto]}/${anoSegundoBoleto}`
        cobrancaSegundoBoleto = `Não haverá cobrança caso o cancelamento seja concluído antes de ${diaFimCiclo}/${numero_meses[mes]} `

    };

    doc.setFontSize(12);
    doc.setTextColor(75, 85, 99);
    doc.setFont("Jakarta", "bold");
    doc.text(`${dataPrimeiroBoleto}`, 17, medidas.yOffset + 58);
    doc.setFontSize(11);
    doc.setFont("Jakarta", "normal");
    doc.text(`• ${cobrancaPrimeiroBoleto}`, 17, medidas.yOffset + 64);

    doc.setFontSize(12);
    doc.setTextColor(75, 85, 99);
    doc.setFont("Jakarta", "bold");
    doc.text(`${dataSegundoBoleto}`, 17, medidas.yOffset + 74);
    doc.setFontSize(11);
    doc.setFont("Jakarta", "normal");
    doc.text(`• ${cobrancaSegundoBoleto}`, 17, medidas.yOffset + 80);

    data(doc, medidas, 190)
    responsavel(doc, medidas, dados)
    rodape(doc, medidas, dados)

    doc.output('dataurlnewwindow');
}