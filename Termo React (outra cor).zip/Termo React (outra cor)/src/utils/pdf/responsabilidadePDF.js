import { jsPDF } from "jspdf";
import { JakartaBold } from "./fonts/JakartaBold-bold"
import { JakartaNormal } from "./fonts/Jakarta-normal"
import { cabecalho, tituloPrincipal, data, responsavel, rodape, inputsAssociados } from "./ConfigPDF";

export const gerarPDFResponsabilidade = (dados) => {
    const doc = new jsPDF();

    const medidas = {
        larguraPag: doc.internal.pageSize.getWidth(),
        alturaPag: doc.internal.pageSize.getHeight(),
        yOffset: 15
    };

    JakartaNormal(doc);
    JakartaBold(doc);


    cabecalho(doc, medidas, "Termo de Responsabilidade de Aparelho");
    // Termo de Responsabilidade Pela Guarda e Uso de Equipamento de Trabalho

    doc.setFontSize(8);
    
    doc.setDrawColor(15, 118, 110);
    doc.setLineWidth(0.8);
    doc.setFillColor(255, 255, 255);
    doc.roundedRect(10, medidas.yOffset + 6, 190, 20, 2, 2, 'FD');
    
    doc.setFontSize(12);
    doc.setFont("Jakarta", "bold");
    doc.setTextColor(15, 118, 110);
    doc.text(`Nome do Colaborador`, 14, medidas.yOffset + 13);
    
    doc.setFontSize(12);
    doc.setTextColor(15, 118, 110);
    doc.text(`CPF`, 140, medidas.yOffset + 13);
    
    medidas.yOffset += 6;
    
    doc.setDrawColor(15, 118, 110); 
    doc.setLineWidth(0.4); 
    doc.setFillColor(226, 232, 240);
    doc.setFontSize(10);
    
    doc.roundedRect(13, medidas.yOffset + 8, 125, 7, 2, 2, 'FD');
    doc.setTextColor(75, 85, 99);
    
    doc.setFillColor(226, 232, 240);
    doc.roundedRect(140, medidas.yOffset + 8, 55, 7, 2, 2, 'FD');
    doc.setTextColor(75, 85, 99);
    
    medidas.yOffset += 4;


    doc.setFontSize(12);
    doc.setTextColor(15, 118, 110);
    
    medidas.yOffset += 22;
    
    tituloPrincipal(doc, "Termo de Responsabilidade pela Guarda e Uso de Aparelho", medidas);
    doc.setDrawColor(15, 118, 110);
    doc.setLineWidth(0.8);
    doc.setFillColor(255, 255, 255);
    doc.roundedRect(10, medidas.yOffset + 6, 190, 165, 2, 2, 'FD')
    
    


    doc.setFontSize(13);
    doc.setFillColor(226, 232, 240);
    doc.setTextColor(15, 118, 110);
    doc.setFont("Jakarta", "bold");
    
    doc.setFontSize(10);
    doc.setTextColor(75, 85, 99);
    
    // doc.setFont("Jakarta", "bold");
    // doc.text('Modelo do Aparelho:', 13, medidas.yOffset + 20);
    // doc.setFont("Jakarta", "normal");
    // doc.text(`${dados.empresa}`, 54, medidas.yOffset + 20);

    doc.setFont("Jakarta", "normal");
    doc.text('Recebi da Associação Comercial e Industrial de São Carlos, CNPJ nº 59.621.003/0001-95, a título de empréstimo, para uso exclusivo, conforme determinado em lei, os equipamentos especificados neste termo de responsabilidade.', 13, medidas.yOffset + 14, { maxWidth: 180, align: 'justify', lineHeightFactor: 1.5});

    doc.text('Comprometendo-me a mantê-los em perfeito estado de conservação, ficando ciente de que:', 13, medidas.yOffset + 34);

    doc.text('• Se o equipamento for danificado ou inutilizado por emprego inadequado, mau uso, ou extravio, autorizo a empresa a fazer desconto em folha de pagamento do valor de Nota Fiscal correspondente ao mesmo', 16, medidas.yOffset + 44, { maxWidth: 170, align: 'justify', lineHeightFactor: 1.5});

    doc.text('• Em caso de dano, inutilização, ou extravio do equipamento deverei comunicar imediatamente ao setor competente', 16, medidas.yOffset + 62, { maxWidth: 175, align: 'justify', lineHeightFactor: 1.5});

    doc.text('• Terminando os serviços ou no caso de rescisão do contrato de trabalho, devolverei o equipamento completo e em perfeito estado de conservação, considerando-se o tempo do uso do mesmo (tempo de vida útil), ao setor competente', 16, medidas.yOffset + 74, { maxWidth: 175, align: 'justify', lineHeightFactor: 1.5});

    doc.text('• Estando os equipamentos em minha posse, estarei sujeito a inspeções sem prévio aviso', 16, medidas.yOffset + 92, { maxWidth: 175, align: 'justify', lineHeightFactor: 1.5});
        
    medidas.yOffset += 95;

    doc.setDrawColor(15, 118, 110);
    doc.setLineWidth(0.8);
    doc.setFillColor(255, 255, 255);
    doc.roundedRect(10, medidas.yOffset + 2, 190, 0, 2, 2, 'FD')

    medidas.yOffset += 2;

    // doc.setFont("Jakarta", "bold");
    // doc.text('Modelo do Aparelho:', 13, medidas.yOffset + 10);
    // doc.setFont("Jakarta", "normal");
    // doc.text(`${dados.empresa}`, 54, medidas.yOffset + 10);



    // doc.setDrawColor(15, 118, 110); 
    // doc.setLineWidth(0.4); 

    
    
    doc.setFont("Jakarta", "bold");
    doc.setTextColor(15, 118, 110);
    doc.text(`Modelo do Aparelho`, 14, medidas.yOffset + 8);
    doc.text(`IMEI`, 141, medidas.yOffset + 8);
    doc.text(`Valor`, 112, medidas.yOffset + 23);
    doc.text(`Estado`, 154, medidas.yOffset + 23);
    doc.text(`Acessórios`, 14, medidas.yOffset + 23);
    doc.text(`Linha Corporativa`, 14, medidas.yOffset + 39);
    doc.text(`PIN - WhatsApp`, 14, medidas.yOffset + 54);
    doc.text(`E-mail`, 112, medidas.yOffset + 39);
    doc.text(`Senha`, 112, medidas.yOffset + 54);
    
    doc.setFillColor(226, 232, 240);
    doc.setFontSize(10);
    doc.setDrawColor(15, 118, 110); 
    doc.setLineWidth(0.2);
    doc.roundedRect(13, medidas.yOffset + 9, 123, 7, 2, 2, 'FD');
    doc.roundedRect(140, medidas.yOffset + 9, 53, 7, 2, 2, 'FD');
    doc.roundedRect(13, medidas.yOffset + 24, 95, 7, 2, 2, 'FD');
    doc.roundedRect(111, medidas.yOffset + 24, 39, 7, 2, 2, 'FD');
    doc.roundedRect(153, medidas.yOffset + 24, 40, 7, 2, 2, 'FD');
    doc.roundedRect(13, medidas.yOffset + 40, 95, 7, 2, 2, 'FD');
    doc.roundedRect(13, medidas.yOffset + 55, 95, 7, 2, 2, 'FD');
    doc.roundedRect(111, medidas.yOffset + 40, 82, 7, 2, 2, 'FD');
    doc.roundedRect(111, medidas.yOffset + 55, 82, 7, 2, 2, 'FD');

    doc.setTextColor(75, 85, 99);
    doc.setFont("Jakarta", "normal");
    doc.text(`${dados.aparelho}`, 15, medidas.yOffset + 14);
    doc.text(`${dados.imei}`, 142, medidas.yOffset + 14);
    doc.text(`${dados.valor}`, 113, medidas.yOffset + 29);
    doc.text(`${dados.acessorios}`, 15, medidas.yOffset + 29);
    doc.text(`${dados.estado}`, 155, medidas.yOffset + 29);
    doc.text(`${dados.telefone}`, 15, medidas.yOffset + 45);
    doc.text(`${dados.whats}`, 15, medidas.yOffset + 60);
    doc.text(`${dados.email}`, 113, medidas.yOffset + 45);
    doc.text(`${dados.senha}`, 113, medidas.yOffset + 60);

    doc.setFontSize(6);
    doc.setFont("Jakarta", "normal");
    doc.text(`§ 1º - Em caso de dano causado pelo empregado, o desconto será lícito, desde de que esta possibilidade tenha sido acordada ou na ocorrência de dolo do empregado - Art. 462, CLT.`, 13, medidas.yOffset + 70);
    
    doc.setFontSize(10);
    doc.setTextColor(75, 85, 99); 
    doc.setFillColor(0, 0, 0);
    doc.rect(10, medidas.yOffset + 110, 80, 0, 'D');
    doc.setFont("Jakarta", "bold");
    doc.text("Assinatura Colaborador", 11, medidas.yOffset + 116);

    doc.setTextColor(75, 85, 99); 
    doc.setFillColor(0, 0, 0);
    doc.rect(121, medidas.yOffset + 110, 79, 0, 'D');
    doc.setFont("Jakarta", "bold");
    doc.text("Assinatura Responsável pela Entrega", 122, medidas.yOffset + 116);
    doc.setFont("Jakarta", "normal");


    data(doc, medidas, 233)
    rodape(doc, medidas, dados)


    doc.output('dataurlnewwindow');
};