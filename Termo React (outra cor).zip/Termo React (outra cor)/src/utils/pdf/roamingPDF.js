import { jsPDF } from "jspdf";
import { JakartaBold } from "../pdf/fonts/JakartaBold-bold"
import { JakartaNormal } from "../pdf/fonts/Jakarta-normal"
import { cabecalho, tituloPrincipal, data, responsavel, rodape, inputsAssociados } from "./ConfigPDF";

export const gerarPDFRoaming = (dados) => {
    const doc = new jsPDF();

    const medidas = {
        larguraPag: doc.internal.pageSize.getWidth(),
        alturaPag: doc.internal.pageSize.getHeight(),
        yOffset: 15
    };

    JakartaNormal(doc);
    JakartaBold(doc);


    cabecalho(doc, medidas, "Roaming Internacional VIVO");
    inputsAssociados(doc, dados, medidas);
    tituloPrincipal(doc, "Contratação de Serviço", medidas);

    doc.setDrawColor(15, 118, 110);
    doc.setLineWidth(0.8);
    doc.setFillColor(255, 255, 255);
    doc.roundedRect(10, medidas.yOffset + 6, 190, 120, 2, 2, 'FD')
    
    doc.setFontSize(13);
    doc.setFillColor(226, 232, 240);
    doc.setTextColor(15, 118, 110);
    doc.setFont("Jakarta", "bold");
    doc.text('Contratação - Roaming Internacional VIVO', 13, medidas.yOffset + 13);
    
    doc.setFontSize(11);
    doc.setTextColor(75, 85, 99);
    
    doc.setFont("Jakarta", "bold");
    doc.text('Período:', 13, medidas.yOffset + 20);
    doc.setFont("Jakarta", "normal");
    doc.text(`${dados.periodo}`, 30, medidas.yOffset + 20);
    
    doc.setFont("Jakarta", "bold");
    doc.text('Valor:', 13, medidas.yOffset + 28);
    doc.setFont("Jakarta", "normal");
    doc.text(`${dados.valor}`, 25, medidas.yOffset + 28);
    
    doc.setFont("Jakarta", "bold");
    doc.text('Data Início:', 13, medidas.yOffset + 36);
    doc.setFont("Jakarta", "normal");
    doc.text(`${dados.dataInicio}`, 35, medidas.yOffset + 36);
    
    doc.setFont("Jakarta", "bold");
    doc.text('Data Fim:', 63, medidas.yOffset + 36);
    doc.setFont("Jakarta", "normal");
    doc.text(`${dados.dataFim}`, 82, medidas.yOffset + 36);
    
    doc.setFont("Jakarta", "bold");
    doc.text('Linha(s):', 13, medidas.yOffset + 44);
    doc.setFont("Jakarta", "normal");
    doc.setTextColor(75, 85, 99);
    const listaLinhas = dados?.linhasAdicionadas || []; 

    for (let i = 0; i < listaLinhas.length; i += 5) {
        doc.text(listaLinhas.slice(i, i + 5).join(',  '), 30, medidas.yOffset + 44); 
        medidas.yOffset += 4;
    }
    
    doc.setDrawColor(15, 118, 110);
    doc.setLineWidth(0.8);
    doc.setFillColor(255, 255, 255);
    doc.roundedRect(10, medidas.yOffset + 48, 190, 0, 2, 2, 'D')
    

    doc.setFontSize(13);
    doc.setFillColor(226, 232, 240);
    doc.setTextColor(15, 118, 110);
    doc.setFont("Jakarta", "bold");
    doc.text('Informações Adicionais', 13, medidas.yOffset + 55);

    doc.setFontSize(10);
    doc.setTextColor(75, 85, 99);

    if (dados.periodo === 'Diária') {
        const infoAdd =  [
            'O pacote de dados é variável de acordo com o local visitado',
            'Tarifa excedente de  R$1,99 por minuto',
            '50 minutos para originar chamadas e recebimento ilimitado de ligações e SMS',
        ]

        infoAdd.forEach(topico => {
            const lines = doc.splitTextToSize(topico, 175);
            doc.text('•', 15, medidas.yOffset + 62);  
            doc.setFont("Jakarta", "normal");
            doc.text(topico, 20, medidas.yOffset + 62);
            medidas.yOffset += (lines.length * 7);
        })
        medidas.yOffset += 34
        
    } else {
        const infoAdd =  [
            'O plano possui período de permanência mínima de 24 meses.',
            'O serviço é cobrado mensalmente, mesmo que não haja utilização.',
            'O Pacote de dados disponibilizado no exterior é o mesmo que a linha possui contratado.',
            'O serviço não é compatível com pacotes de dados adicionais.',
            'Inclui ligações e SMS ilimitados do exterior para o Brasil e dentro do país visitado',
            'O serviço não contempla ligações originadas no Brasil para o exterior.',
            'Cancelamento antes do fim da fidelidade está sujeito a multa correspondente a 80% do valor contratado multiplicado pelos meses restantes.',
        ]


        infoAdd.forEach(topico => {
            const lines = doc.splitTextToSize(topico, 175);
            doc.text('•', 15, medidas.yOffset + 63); 
            doc.setFont("Jakarta", "normal");
            doc.text(lines, 20, medidas.yOffset + 63); 
            medidas.yOffset += (lines.length * 7);
        });
    }

    data(doc, medidas, 210)
    responsavel(doc, medidas, dados)
    rodape(doc, medidas, dados)


    doc.output('dataurlnewwindow');
};