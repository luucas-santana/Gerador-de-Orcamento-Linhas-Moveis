function RadioField({
  label,
  size = "col-span-1",
  value,
  onChange,
  name,
}) {
  return (
    <div className={`flex relative flex-col ${size}`}>
      <label className="bg-white z-10 absolute left-3 -top-4 p-1 text-[#333B69] font-bold whitespace-nowrap text-base">
        {label}
      </label>

      <div className="flex items-center justify-center gap-5 border-3 py-4 px-2 rounded-xl border-[#718EBF]">

        <label className="flex items-center gap-2 cursor-pointer">
          <p>Novo</p>
          <input
            type="radio"
            name={name}
            value="Novo"
            checked={value === "Novo"}
            onChange={onChange}
            className="w-5 h-5 accent-[#333B69]"
          />
        </label>

        <label className="flex mouse items-center gap-2 cursor-pointer">
          <p>Usado</p>
          <input
            type="radio"
            name={name}
            value="Usado"
            checked={value === "Usado"}
            onChange={onChange}
            className="w-5 h-5 accent-[#333B69]"
          />
        </label>

      </div>
    </div>
  );
}

export default RadioField;