const TagField = ({ label, icone: Icon, size, itens, onRemover }) => {
    return (
        <div className={`flex relative flex-col ${size}`}>
            <label className='bg-white z-10 absolute left-3 -top-4 p-1 text-[#333B69] font-bold whitespace-nowrap text-base'>
                {label}
            </label>
            <div className="flex flex-wrap gap-2 relative border-3 py-4 px-2 rounded-xl border-[#718EBF]">
                <Icon className="text-[#333B69] shrink-0" size={32} color="#333b69" weight="duotone" />
                
                {itens.length === 0 && (
                    <span className="text-[#333B69]/50 font-semibold text-sm self-center">
                        Nenhuma linha adicionada
                    </span>
                )}

                {itens.map((item) => (
                    <span key={item} className="flex items-center gap-1 bg-slate-200/50 border-2 border-[#333b69]  text-sm font-semibold px-3 py-1 rounded-full">
                        {item}
                        <button type="button" className="cursor-pointer font-black hover:text-red-500" onClick={() => onRemover(item)}>✕</button>
                    </span>
                ))}
            </div>
        </div>
    )
}

export default TagField