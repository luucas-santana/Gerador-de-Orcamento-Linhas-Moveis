
import { Link, NavLink, Routes, Route, BrowserRouter } from 'react-router'
import { FileTextIcon, PhoneXIcon, AirplaneTakeoffIcon, ArrowsLeftRightIcon,HouseLineIcon, CurrencyCircleDollarIcon, HandDepositIcon } from "@phosphor-icons/react"
import Cancelamento from '../pages/Cancelamento';
import Roaming from '../pages/Roaming';
import ExpandedMenu from './ExpandedMenu';
import Comissao from "../pages/Comissao";
import Responsabilidade from "../pages/Responsabilidade"
import { useState } from "react";
import { PiggyBank } from 'lucide-react';

<BrowserRouter>
<Routes>
    <Route path="/cancelamento" element={<Cancelamento />}/>
    <Route path="/roaming" element={<Roaming />}/>
    <Route path="/comissao" element={<Comissao/>}/>
    <Route path="/responsabilidade" element={<Responsabilidade/>}/>
</Routes>
</BrowserRouter>

function Sidebar() {
    const [expanded, setExpanded] = useState(null);
    return(
    <div className="flex h-full">

    <aside className="bg-teal-700 w-60 border-r-2 border-slate-300 flex flex-col">
        <div className='py-6 flex justify-center mb-4'>       
            <img width={180} src="./src/assets/Logotipo_ACISC_Branco_2025.webp" alt=""/>
        </div>
        
        <nav className="flex flex-1 gap-2 flex-col">
            <ExpandedMenu 
            titulo="Início"
            iconTitulo={(isActive, open) => <HouseLineIcon size={24} weight={open ? "fill" : "regular"} />}
            onToggle={() => setExpanded(expanded === "Início" ? null : "Início")}
            href="/"
            onNavigate={() => setExpanded(null)}
            open={expanded === "Início"}
            expanded={expanded}
            />


            <ExpandedMenu 
            titulo="Termos"
            iconTitulo={(isActive, open) => <FileTextIcon size={24} weight={open ? "fill" : "regular"} />}
            expand
            itens={[
                { label: "Cancelamento", to: "/cancelamento", icon: (isActive) => <PhoneXIcon size={20} weight={isActive ? "fill" : "regular"} /> },
                { label: "Internacional", to: "/roaming", icon: (isActive) => <AirplaneTakeoffIcon size={20} weight={isActive ? "fill" : "regular"} /> },
                { label: "Transferência Interna", to: "/transferencia", icon: (isActive) => <ArrowsLeftRightIcon size={20} weight={isActive ? "fill" : "regular"} /> },
                { label: "Responsabilidade", to: "/responsabilidade", icon: (isActive) => <HandDepositIcon  size={20} weight={isActive ? "fill" : "regular"} /> },
                ]}
            open={expanded === "Termo"}
            onToggle={() => setExpanded(expanded === "Termo" ? null : "Termo")}
            />
            
            {/* <hr className='text-slate-300 m-2 '/> */}
                    
            {/* <ExpandedMenu 
            titulo="Comissao"
            iconTitulo={(isActive, open) => <CurrencyCircleDollarIcon   size={24} weight={open ? "fill" : "regular"} />}
            onToggle={() => setExpanded(expanded === "Comissao" ? null : "Comissao")}
            href="/comissao"
            open={expanded === "Comissao"}
            onNavigate={() => setExpanded(null)}
            expanded={expanded}
            /> */}

        </nav>

        <footer className='flex justify-center my-4 text-center text-teal-500 text-xs font-semibold'>
            <span >
                Desenvolvido por <br /> Lucas Santana - 2026
            </span>
        </footer>

    </aside>

    </div>
    )
}

export default Sidebar