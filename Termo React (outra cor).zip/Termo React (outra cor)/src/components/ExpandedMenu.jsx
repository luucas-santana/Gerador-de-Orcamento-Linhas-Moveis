
import { useState } from "react";
import { CaretDownIcon } from "@phosphor-icons/react"
import { NavLink } from "react-router-dom";

export default function ExpandedMenu({titulo, iconTitulo, itens=[], open, onToggle, expanded, expand=false, href, onNavigate}) {

// console.log(typeof iconTitulo) 
        
    return (
    <div className="my-1">
        <div className='flex items-center cursor-pointer'>

            {expand ? (
                <button onClick={onToggle}
                className={`w-full flex items-center space-x-2 cursor-pointer px-4 py-2 mx-2 ${open ? "bg-slate-200 rounded-2xl text-teal-700 border border-slate-300 font-black"
                    : 
                    "hover:bg-white/10 font-semibold text-slate-200"}`}
                    >

                
                    {typeof iconTitulo === 'function' ? iconTitulo(null, open) : iconTitulo}
                    <p className='text-sm'>{titulo}</p>
                {expand && 
                    <span className={`{transition-all duration-500 ${open ? "rotate-180" : "none" }`}><CaretDownIcon weight={open ? "bold" : "regular"} /></span>
                }
            </button>
            ) :
            (
                <NavLink
                    to={href}
                    onClick={onNavigate}
                    className={({ isActive }) =>
                        `w-full flex items-center space-x-2 cursor-pointer py-2 px-4 mx-2 ${
                        isActive && !expanded
                        ? "bg-slate-200 text-teal-700 rounded-2xl border border-slate-300 font-black"
                        // ? "bg-linear-to-t font-black rounded-2xl from-teal-500 border border-teal-500/80 text-slate-200 to-transparent"
                        : "hover:bg-white/10 font-semibold rounded-xl text-slate-200"
                        }`
                    }
                    >
                    {({ isActive }) => ( 
                    <>
                        {typeof iconTitulo === 'function' ? iconTitulo(null, isActive && !expanded) : iconTitulo}
                        <p className="text-sm">{titulo}</p>
                    </>
                    )}
            </NavLink>
            )}
        
        </div>

        {expand && 
            <div>
                <div className={`
                    grid transition-all duration-300 ease-in-out pl-8
                    ${open ? "grid-rows-[1fr] opacity-100 mt-2" : "grid-rows-[0fr] opacity-0"}
                `}>
                    <div className="overflow-hidden">
                    <div className="flex">
                        <div className='w-0.5 bg-slate-300 '></div>

                        <ul className="list-none w-full px-2 space-y-2">
                            {itens.map((item) => (
                            <li key={item.to}>
                                <NavLink
                                to={item.to}
                                className={({ isActive }) => 
                                    `block w-full rounded-xl ${
                                    isActive 
                                    ? "bg-teal-600 rounded-2xl text-white border border-teal-500 font-black" 
                                    : "font-normal text-slate-200 bg-transparent hover:bg-white/10"
                                    }`}>
                                {({ isActive }) => (
                                    <span className="flex items-center space-x-2 text-xs p-2">
                                    {typeof item.icon === 'function' ? item.icon(isActive) : item.icon}
                                    <span>{item.label}</span>
                                    </span>
                                )}
                                </NavLink>
                            </li>
                            ))}
                        </ul>
                    </div>
                    </div>
                </div>

                
            </div>
        }

    </div>
    )
}


"bg-linear-to-l from-white/0 to-[#2FD0CA]  rounded-r-xl font-bold"
"absolute left-0 w-2 h-14 bg-white rounded-full"