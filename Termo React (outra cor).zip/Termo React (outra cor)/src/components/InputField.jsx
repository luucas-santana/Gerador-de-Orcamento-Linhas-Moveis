import { PlusCircleIcon  } from "@phosphor-icons/react";

const InputField = ({ label, icone: Icon, placeholder = "", type = "text", size, button = false, onButton, onValueChange, ...rest }) => {
    return (
        <div className={`flex relative flex-col ${size}`}>
            <label className='bg-white z-10 absolute left-3 -top-4 p-1 text-[#333B69] font-bold whitespace-nowrap text-base'>{label}</label>
            <div className="flex items-center relative space-x-2 border-3 py-4 px-2 rounded-xl border-[#718EBF]">
                <Icon className="text-[#333B69] shrink-0" size={32} color="#333b69" weight="duotone" />
                <input {...rest} type={type} placeholder={placeholder} className="w-full outline-none text-[#333B69] font-semibold text-sm placeholder:text-[#333B69]/50 disabled:opacity-50 disabled:cursor-not-allowed" />
                
                {button && (
                    <button type="button" onClick={onButton} className="flex justify-center cursor-pointer hover:scale-115 hover:duration-150 transition-all active:scale-90">
                        <PlusCircleIcon size={24} color="#333b69" weight="duotone" />
                    </button>
                )}
            </div>
        </div>
    )
}

export default InputField