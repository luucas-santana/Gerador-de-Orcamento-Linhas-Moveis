

function SelectField({ label, icone: Icon, size = 'col-span-1', options = [], ...rest }) {    
    
        return (
        <div className={`flex relative flex-col ${size}`}>
            <label className='bg-white z-10 absolute left-3 -top-4 p-1 text-[#333B69] font-bold whitespace-nowrap text-base'>{label}</label>
            <div className="flex space-x-2 relative border-3 py-4 px-2 rounded-xl border-[#718EBF]">
                    <Icon className="text-[#333B69] shrink-0" size={32} color="#333b69" weight="duotone" />

                <select {...rest} defaultValue="" className="w-full cursor-pointer bg-transparent outline-none text-[#333B69] font-semibold text-sm placeholder:text-[#333B69]/50">
                <option value="" disabled>Selecione</option>
                {options.map((opt) => {
                    const value = typeof opt === 'string' ? opt : opt.value;
                    const label = typeof opt === 'string' ? opt : opt.label;
                    return (
                        <option key={value} value={value}>{label}</option>
                    )
                })}
                </select>
            </div>
        </div>
    )
}

export default SelectField




